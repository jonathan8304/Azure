#!/bin/bash
sudo bash -c "echo net.ipv4.ip_forward=1 >> /etc/sysctl.conf"
sudo sysctl -p /etc/sysctl.conf
